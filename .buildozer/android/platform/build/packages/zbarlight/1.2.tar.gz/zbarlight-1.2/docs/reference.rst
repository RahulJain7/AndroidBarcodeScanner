Reference
=========

.. automodule:: zbarlight
    :members: scan_codes, qr_code_scanner

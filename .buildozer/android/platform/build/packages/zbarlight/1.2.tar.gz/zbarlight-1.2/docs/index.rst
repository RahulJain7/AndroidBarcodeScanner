.. toctree::
    :maxdepth: 2
    :hidden:

    intro.rst
    reference.rst

.. include:: ../README.rst
